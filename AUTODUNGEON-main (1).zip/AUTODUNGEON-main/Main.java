import AUTODUNGEON.DungeonController;

public class Main {
    public static void main(String[] args) {
        DungeonController dungeon = new DungeonController();

        dungeon.update();
    }
}
